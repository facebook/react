# TodoMVC-director

This is the exact copy of the React-powered [TodoMVC](http://todomvc.com/labs/architecture-examples/react/). To test it, use [bower](http://bower.io) to fetch the dependencies:

`bower install`

Then fire up a server here:

`python -m SimpleHTTPServer`

And go visit `localhost:8000`.
